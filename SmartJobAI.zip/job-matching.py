import pdfplumber
import docx
import spacy
import json
import firebase_admin
from firebase_admin import credentials, storage, firestore

# Initialize Firebase (Avoid multiple initializations)
if not firebase_admin._apps:
    cred = credentials.Certificate("path/to/your/firebase-adminsdk.json")
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'smartjobai.appspot.com'
    })

db = firestore.client()

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# Predefined list of skills (extendable)
SKILL_SET = {"python", "javascript", "java", "sql", "html", "css", "machine learning", "data science", "react"}

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file."""
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:  # Ensure the page contains extractable text
                    text += page_text + "\n"
    except Exception as e:
        print(f"Error extracting PDF text: {e}")
    
    return text.strip() if text.strip() else "No extractable text found."

def extract_text_from_docx(docx_path):
    """Extract text from a DOCX file."""
    try:
        doc = docx.Document(docx_path)
        return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])
    except Exception as e:
        print(f"Error extracting DOCX text: {e}")
        return "Error reading document."

def extract_skills(text):
    """Extract skills from resume text using NLP."""
    doc = nlp(text.lower())  
    words = {token.text for token in doc}

    # Improve extraction using simple keyword matching
    matched_skills = [skill for skill in SKILL_SET if skill in text.lower()]

    return list(set(words & SKILL_SET) | set(matched_skills))  # Combine methods

def find_matching_jobs(skills):
    """Find job listings from Firestore that match the extracted skills."""
    job_matches = []
    
    try:
        jobs_ref = db.collection("jobs").stream()
        for job in jobs_ref:
            job_data = job.to_dict()
            job_skills = set(job_data.get("skills", []))

            # Match if at least one skill overlaps
            if job_skills & set(skills):
                job_matches.append(job_data)
    except Exception as e:
        print(f"Error fetching jobs: {e}")

    return job_matches

def process_resume(file_path, file_type):
    """Process resume file, extract skills, and match jobs."""
    if file_type == "pdf":
        text = extract_text_from_pdf(file_path)
    elif file_type == "docx":
        text = extract_text_from_docx(file_path)
    else:
        raise ValueError("Unsupported file type! Please upload a PDF or DOCX file.")

    if text.startswith("Error") or text == "No extractable text found.":
        return {"error": text}

    skills = extract_skills(text)
    matched_jobs = find_matching_jobs(skills)

    return {
        "extracted_text": text[:500] + "..." if len(text) > 500 else text,  # Preview of extracted text
        "skills": skills,
        "matched_jobs": matched_jobs
    }

# Example usage
if __name__ == "__main__":
    file_path = "path/to/sample-resume.pdf"  # Replace with actual path
    file_type = "pdf"  # Change to "docx" if needed
    result = process_resume(file_path, file_type)

    print(json.dumps(result, indent=2))