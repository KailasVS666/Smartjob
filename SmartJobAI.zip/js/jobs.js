import { db, collection, getDocs } from "./firebase-config.js";

const jobList = document.getElementById("jobList");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const locationFilter = document.getElementById("locationFilter");

// Function to render jobs
function renderJobs(jobs) {
  jobList.innerHTML = ""; // Clear previous jobs
  jobs.forEach((job) => {
    const jobCard = document.createElement("div");
    jobCard.className = "col-md-4 mb-4";
    jobCard.innerHTML = `
      <div class="card h-100">
        <div class="card-body">
          <h5 class="card-title">${job.title}</h5>
          <p class="card-text"><strong>Company:</strong> ${job.company}</p>
          <p class="card-text"><strong>Location:</strong> ${job.location}</p>
          <p class="card-text"><strong>Category:</strong> ${job.category}</p>
          <p class="card-text">${job.description.substring(0, 100)}...</p>
          <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#jobModal" data-job='${JSON.stringify(job)}'>View Details</button>
        </div>
      </div>
    `;
    jobList.appendChild(jobCard);
  });
}

// Fetch jobs from Firestore
async function fetchJobs() {
  try {
    const querySnapshot = await getDocs(collection(db, "jobs"));
    const jobs = querySnapshot.docs.map(doc => doc.data());
    renderJobs(jobs);
  } catch (error) {
    console.error("Error fetching jobs:", error);
  }
}

// Event listener for job detail modal
document.getElementById("jobModal").addEventListener("show.bs.modal", function(event) {
  const button = event.relatedTarget;
  const job = JSON.parse(button.getAttribute("data-job"));
  document.getElementById("modalJobTitle").textContent = job.title;
  document.getElementById("modalJobCompany").textContent = job.company;
  document.getElementById("modalJobLocation").textContent = job.location;
  document.getElementById("modalJobCategory").textContent = job.category;
  document.getElementById("modalJobDescription").textContent = job.description;
  document.getElementById("modalJobApplyLink").href = job.applyLink;
});

// Call fetchJobs when the page loads
document.addEventListener("DOMContentLoaded", fetchJobs);