// 📌 Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  GoogleAuthProvider,
  signInWithPopup
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  getDocs,
  setDoc,
  doc
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

// 📌 Firebase configuration (🔹 Always keep credentials secure)
const firebaseConfig = {
  apiKey: "AIzaSyCjijs8YFs3DUbvr_uR0ZXQeKuqn9tQ3Wg",
  authDomain: "smartjobai.firebaseapp.com",
  projectId: "smartjobai",
  storageBucket: "smartjobai.appspot.com",
  messagingSenderId: "854391043012",
  appId: "1:854391043012:web:d206ebc5fadf7d420f2a91"
};

// 📌 Initialize Firebase services
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// 📌 Google Authentication
const googleProvider = new GoogleAuthProvider();

/**
 * 🔹 Function to Sign Up with Email & Password
 */
async function signUp(email, password) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Save user to Firestore
    await setDoc(doc(db, "users", user.uid), {
      email: user.email,
      createdAt: new Date(),
      provider: "email"
    });
    
    return user;
  } catch (error) {
    console.error("Error signing up:", error.message);
    throw error;
  }
}

/**
 * 🔹 Function to Sign In with Email & Password
 */
async function signIn(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error signing in:", error.message);
    throw error;
  }
}

/**
 * 🔹 Function to Sign In with Google
 */
async function signInWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Save Google user to Firestore
    await setDoc(doc(db, "users", user.uid), {
      email: user.email,
      name: user.displayName,
      profilePic: user.photoURL,
      createdAt: new Date(),
      provider: "google"
    }, { merge: true });
    
    return user;
  } catch (error) {
    console.error("Error with Google Sign-In:", error.message);
    throw error;
  }
}

/**
 * 🔹 Function to Sign Out
 */
async function logOut() {
  try {
    await signOut(auth);
    console.log("User signed out successfully");
  } catch (error) {
    console.error("Error signing out:", error.message);
  }
}

/**
 * 🔹 Function to Fetch Users from Firestore
 */
async function fetchUsers() {
  try {
    const usersCollection = collection(db, "users");
    const usersSnapshot = await getDocs(usersCollection);
    const usersList = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    return usersList;
  } catch (error) {
    console.error("Error fetching users:", error.message);
    throw error;
  }
}

// 📌 Export functions and Firebase instances for usage in other files
export {
  auth,
  db,
  signUp,
  signIn,
  signInWithGoogle,
  logOut,
  fetchUsers,
  collection,
  getDocs
};