const express = require("express");
const multer = require("multer");
const path = require("path");
const { spawn } = require("child_process");
const cors = require("cors");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS (allow frontend to communicate with backend)
app.use(cors());
app.use(express.json());

// Ensure 'uploads' directory exists
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure Multer for file uploads
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only PDF and DOCX files are allowed!"), false);
    }
  }
});

// Upload resume and process it
app.post("/upload-resume", upload.single("resume"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded or invalid file type!" });
  }
  
  const filePath = path.resolve(req.file.path);
  const fileType = req.file.mimetype === "application/pdf" ? "pdf" : "docx";
  
  // Call Python script to process resume
  const pythonProcess = spawn("python3", ["resume-parser.py", filePath, fileType]);
  
  let output = "";
  let errorOutput = "";
  
  pythonProcess.stdout.on("data", (data) => {
    output += data.toString();
  });
  
  pythonProcess.stderr.on("data", (data) => {
    errorOutput += data.toString();
    console.error(`Python Error: ${data}`);
  });
  
  pythonProcess.on("close", (code) => {
    fs.unlink(filePath, (err) => {
      if (err) console.error(`Failed to delete file: ${err}`);
    });
    
    if (code === 0) {
      try {
        const jsonResponse = JSON.parse(output);
        res.json(jsonResponse);
      } catch (err) {
        res.status(500).json({ error: "Invalid JSON response from Python script" });
      }
    } else {
      res.status(500).json({ error: "Error processing resume", details: errorOutput });
    }
  });
});

// Middleware for handling Multer errors
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: `Multer error: ${err.message}` });
  } else if (err) {
    return res.status(400).json({ error: err.message });
  }
  next();
});

// Server status check
app.get("/", (req, res) => {
  res.send("Job Matching API is running...");
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});