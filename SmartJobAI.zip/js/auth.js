// Import Firebase services
import { auth, db } from "./firebase-config.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { doc, setDoc, getDoc } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

/**
 * 🔹 Handle Firebase Authentication Errors
 */
function handleAuthError(error) {
  console.error("Firebase Auth Error:", error); // Log error for debugging
  let message = "An error occurred!";
  
  switch (error.code) {
    case "auth/email-already-in-use":
      message = "This email is already registered. Try logging in instead.";
      break;
    case "auth/weak-password":
      message = "Password must be at least 6 characters long.";
      break;
    case "auth/invalid-email":
      message = "Please enter a valid email address.";
      break;
    case "auth/user-not-found":
      message = "No account found with this email. Please sign up first.";
      break;
    case "auth/wrong-password":
      message = "Incorrect password. Please try again.";
      break;
    case "auth/popup-closed-by-user":
      message = "Google sign-in was canceled. Please try again.";
      break;
    default:
      message = error.message; // Show unexpected errors
  }
  
  alert(message);
}

/**
 * 🔹 Store User in Firestore (if new)
 */
async function saveUserToFirestore(user, provider) {
  try {
    const userRef = doc(db, "users", user.uid);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      await setDoc(userRef, {
        uid: user.uid,
        email: user.email,
        name: user.displayName || "Anonymous",
        profilePic: user.photoURL || "",
        createdAt: new Date(),
        provider
      });
    }
  } catch (error) {
    console.error("Firestore Error:", error);
  }
}

// 📌 Select form elements (check if they exist before adding event listeners)
const signupForm = document.getElementById("signupForm");
const loginForm = document.getElementById("loginForm");
const googleLoginBtn = document.getElementById("googleLogin");

/**
 * 🔹 Email/Password Signup
 */
if (signupForm) {
  signupForm.addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value.trim();
    
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await saveUserToFirestore(userCredential.user, "email");
      
      alert("Signup successful!");
      window.location.href = "profile.html"; // Redirect to profile page
    } catch (error) {
      handleAuthError(error);
    }
  });
}

/**
 * 🔹 Email/Password Login
 */
if (loginForm) {
  loginForm.addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();
    
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("Login successful!");
      window.location.href = "profile.html"; // Redirect
    } catch (error) {
      handleAuthError(error);
    }
  });
}

/**
 * 🔹 Google Sign-In
 */
if (googleLoginBtn) {
  googleLoginBtn.addEventListener("click", async function() {
    const provider = new GoogleAuthProvider();
    
    try {
      const userCredential = await signInWithPopup(auth, provider);
      await saveUserToFirestore(userCredential.user, "google");
      
      alert("Google Login successful!");
      window.location.href = "profile.html"; // Redirect
    } catch (error) {
      handleAuthError(error);
    }
  });
}

/**
 * 🔹 Authentication State Listener
 * Keeps user logged in even after page reload
 */
onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("User is logged in:", user.email);
    // Optional: Redirect logged-in users to their profile page
    if (window.location.pathname.includes("login.html") || window.location.pathname.includes("signup.html")) {
      window.location.href = "profile.html";
    }
  } else {
    console.log("No user logged in.");
  }
});