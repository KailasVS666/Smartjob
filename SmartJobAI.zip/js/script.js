// ✅ Import Firebase Modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";

// ✅ Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyA_xa1yEMlK8IpfmmXoQDdCcRU4SU7dewg",
  authDomain: "smart-job-e6d76.firebaseapp.com",
  projectId: "smart-job-e6d76",
  storageBucket: "smart-job-e6d76.appspot.com",
  messagingSenderId: "630917187531",
  appId: "1:630917187531:web:fb4e3bd64f7b4374fc584e"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// ✅ Handle User Sign-Up
document.addEventListener("DOMContentLoaded", function() {
  const signupForm = document.getElementById("signup-form");
  const loginForm = document.getElementById("login-form");
  
  if (signupForm) {
    signupForm.addEventListener("submit", function(event) {
      event.preventDefault();
      const email = document.getElementById("signup-email").value;
      const password = document.getElementById("signup-password").value;
      
      createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          document.getElementById("signup-message").innerText = "✅ Account created successfully!";
          signupForm.reset();
        })
        .catch((error) => {
          document.getElementById("signup-message").innerText = "❌ Error: " + error.message;
        });
    });
  }
  
  if (loginForm) {
    loginForm.addEventListener("submit", function(event) {
      event.preventDefault();
      const email = document.getElementById("login-email").value;
      const password = document.getElementById("login-password").value;
      
      signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          document.getElementById("login-message").innerText = "✅ Login successful!";
          setTimeout(() => {
            window.location.href = "dashboard.html"; // Redirect after login
          }, 1000);
        })
        .catch((error) => {
          document.getElementById("login-message").innerText = "❌ Error: " + error.message;
        });
    });
  }
});