import pdfplumber
import docx
import nltk
import spacy
import json
import firebase_admin
from firebase_admin import credentials, storage, firestore

# Initialize Firebase
cred = credentials.Certificate("path/to/your/firebase-adminsdk.json")
firebase_admin.initialize_app(cred, {
    'storageBucket': 'smartjobai.appspot.com'
})
db = firestore.client()

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# Predefined list of skills (extendable)
SKILL_SET = {"python", "javascript", "java", "sql", "html", "css", "machine learning", "data science", "react"}

def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file."""
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() + "\n"
    return text

def extract_text_from_docx(docx_path):
    """Extract text from a DOCX file."""
    doc = docx.Document(docx_path)
    return "\n".join([para.text for para in doc.paragraphs])

def extract_skills(text):
    """Extract skills from resume text using NLP."""
    doc = nlp(text.lower())  # Convert to lowercase for uniformity
    words = {token.text for token in doc}
    return list(words & SKILL_SET)  # Find matching skills

def find_matching_jobs(skills):
    """Find job listings from Firestore that match the extracted skills."""
    job_matches = []
    jobs_ref = db.collection("jobs").stream()

    for job in jobs_ref:
        job_data = job.to_dict()
        job_skills = set(job_data.get("skills", []))
        
        # Matching threshold (adjustable)
        if len(job_skills & set(skills)) > 0:
            job_matches.append(job_data)

    return job_matches

def process_resume(file_path, file_type):
    """Process resume file, extract skills, and match jobs."""
    if file_type == "pdf":
        text = extract_text_from_pdf(file_path)
    elif file_type == "docx":
        text = extract_text_from_docx(file_path)
    else:
        raise ValueError("Unsupported file type!")

    skills = extract_skills(text)
    matched_jobs = find_matching_jobs(skills)

    return {
        "skills": skills,
        "matched_jobs": matched_jobs
    }

# Example usage
if __name__ == "__main__":
    file_path = "path/to/sample-resume.pdf"  # Replace with actual path
    file_type = "pdf"  # Change to "docx" if needed
    result = process_resume(file_path, file_type)

    print(json.dumps(result, indent=2))